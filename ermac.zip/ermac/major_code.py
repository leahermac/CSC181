from flask import Flask, render_template, request
import sqlite3 as sql

app = Flask(__name__)

#The most annoying part -_-

class Student(object):
	def __init__(self, idnum, firstname, lastname, middlename, sex, Course, Yr):
		self.id_num = idnum
		self.fname = firstname
		self.lname = lastname
		self.mname = middlename
		self.sex = sex
		self.course = Course
		self.year = Yr

conn = sql.connect('database.db')
conn.execute('CREATE TABLE IF NOT EXISTS stud_cour (cour_id TEXT PRIMARY KEY, cour_name TEXT, col_sch TEXT)')
cur = conn.cursor()

cur.execute("INSERT OR IGNORE INTO stud_cour(cour_id, cour_name, col_sch) VALUES ('BSCS', 'Bachelor of Science in Computer Science', 'SCS')")
cur.execute("INSERT OR IGNORE INTO stud_cour(cour_id, cour_name, col_sch) VALUES ('BSIT', 'Bachelor of Science in Information Technology', 'SCS')")
cur.execute("INSERT OR IGNORE INTO stud_cour(cour_id, cour_name, col_sch) VALUES ('BSECT', 'Bachelor of Science in Electronics and Computer Technology', 'SCS')")
cur.execute("INSERT OR IGNORE INTO stud_cour(cour_id, cour_name, col_sch) VALUES ('ECET', 'Electrical and Computer Engineering Technology', 'SCS')")

conn.execute('CREATE TABLE IF NOT EXISTS stud_record(ID TEXT PRIMARY KEY  NOT NULL CHECK(length(ID)=9), f_name TEXT  CHECK(length(f_name)>0 AND length(f_name)<=20 ), m_name TEXT CHECK (length(m_name)>0 AND length(m_name)<=20 ), l_name TEXT CHECK (length(l_name)>0 AND length(l_name)<=20 ), Sex TEXT CHECK(length(Sex)=1), Course TEXT CHECK(length(Course)>0 AND length(Course)<=20 ), yr_lvl INTEGER CHECK(length(yr_lvl)=1), FOREIGN KEY(Course) REFERENCES stud_Courses(course_id))')

print"Successfully Executed"

conn.execute("CREATE VIEW IF NOT EXISTS result AS SELECT cour_id, col_sch, l_name, f_name, m_name, cour_name, yr_lvl FROM stud_record JOIN stud_cour WHERE stud_cour.cour_id = stud_record.Course")
conn.execute("CREATE VIEW IF NOT EXISTS ALL_info AS SELECT cour_id, col_sch, cour_name, ID, f_name, m_name, l_name, Sex, yr_lvl FROM stud_record JOIN stud_cour WHERE stud_cour.cour_id = stud_record.Course")

print"Successfully Executed"	

conn.close()

#For homepage

@app.route("/")
def home():
	return render_template("home_er.html")

#For Add

@app.route("/add", methods = ['POST', 'GET'])
def add():
	return render_template("login_form.html")

@app.route("/adding", methods = ['POST', 'GET'])
def adding():
	if request.method == "POST":
		try:
			print"Successfully Executed"
			id_no = request.form['ID_Number']
			print id_no
			firstname = request.form['FirstName']
			middlename = request.form['MiddleName']
			lastname = request.form['LastName']
			sex = request.form['Sex']
			course = request.form['Course']
			Year = request.form['SchoolYear']

			student = Student(id_no, firstname, lastname, middlename, sex, course, Year)
			print"Successfully Executed"
			print student.fname
			print student.id_num
			print student.lname
			print student.mname
			print student.sex
			print student.course
			print student.year
			with sql.connect("database.db") as conn:
				cur = conn.cursor()
				print"Successfully Executedzzzzzz"

				cur.execute(
					"INSERT INTO stud_record(ID,f_name,m_name,l_name, Sex, Course,yr_lvl) VALUES(?,?,?,?,?,?,?)",
					(student.id_num, student.fname, student.lname, student.mname, student.sex, student.course, student.year))
				print "hello"
				conn.commit()

				print"Successfully Executed1111111"
				message = "Successfully Added to the Record."

		except:
			print"Failed to Execute"
			conn.rollback()
			message = "Fail to Add Record."

		finally:
			print"--------"
			conn = sql.connect("database.db")
			conn.row_factory = sql.Row
			cur = conn.cursor()
			cur.execute("SELECT * FROM stud_record")
			rows = cur.fetchall()
			return render_template("result_list.html", rows = rows, message = message)
			conn.close()

#For Delete

@app.route("/delete", methods = ['POST', 'GET'])
def delete():
	conn = sql.connect("database.db")
	conn.row_factory = sql.Row
	cur = conn.cursor()
	cur.execute("SELECT * FROM stud_record")
	rows = cur.fetchall()
	conn.close()
	return render_template("delete_er.html", rows = rows)

@app.route("/deleting", methods = ['POST', 'GET'])
def deleting_done():
	if request.method == "POST":
		try:
			id_no = request.form['ID_Number']
			print id_no
			with sql.connect("database.db") as conn:
				print"Successfully Executed"
				cur = conn.cursor()
				cur.execute("SELECT * FROM stud_record")
				for row in cur.fetchall():
					print row
					if row[0] == id_no:
						cur.execute("DELETE FROM stud_record WHERE ID = ?", (id_no,))
						conn.commit()
						print "horaaaay"
						message = "Successfully Deleted"
						break
					else:
						message = "Failure to detect that student."

		except:
			message = "Fail to Delete"

		finally:
			conn = sql.connect("database.db")
			conn.row_factory = sql.Row
			cur = conn.cursor()
			cur.execute("SELECT * FROM stud_record")
			rows = cur.fetchall()
			return render_template("result_list.html", rows = rows, message = message)
			conn.close()

#For Update

@app.route("/update", methods = ['POST', 'GET'])
def update():
	conn = sql.connect("database.db")
	conn.row_factory = sql.Row
	cur = conn.cursor()
	cur.execute("SELECT * FROM stud_record")
	rows = cur.fetchall()
	return render_template("update_er.html",rows=rows)

@app.route("/updating", methods = ['POST', 'GET'])
def updating_done():
	if request.method == "POST":
		try:
			id_no = request.form['ID_Number']
			print"Successfully Executed"
			with sql.connect("database.db") as conn:
				print"Successfully Executed"
				cur = conn.cursor()
				cur.execute("SELECT * FROM stud_record")
				for row in cur.fetchall():
					if row[0] == id_no:
						print row
						dummy = row
						message = "The student exist."
						break
					else:
						message = "The student doesnt exist."
						dummy = " "

		except:
			message = "SYNTAX ERROR"
			dummy = " "

		finally:
			return render_template("new_update.html", message = message, dummy = dummy)
		conn.close()

@app.route("/updating2", methods = ['POST', 'GET'])
def updating_final():
	if request.method == "POST":
		try:
			id_no = request.form['ID_Number']
			print id_no
			firstname = request.form['Firstname']
			print firstname
			lastname = request.form['LastName']
			middlename = request.form['MiddleName']
			sex = request.form['Sex']
			course = request.form['Course']
			Year = request.form['SchoolYear']

			print "heeeey"
			with sql.connect("database.db") as conn:
				cur = conn.cursor()
				cur.execute("SELECT * FROM stud_record")
				for row in cur.fetchall():
					print row
					if row[0] == id_no:
						cur.execute("UPDATE stud_record set f_name = ?, l_name = ?, m_name = ?, Sex = ?, Course = ?, yr_lvl = ? where ID = ?", (firstname, lastname, middlename, sex, course, Year, id_no))
						conn.commit()
						message = "Successfully Updated"
						break
					elif not row[0] == id_no:
						message = "SYNTAX ERROR"

		except:
			message = "Failure to Update."

		finally:
			conn = sql.connect("database.db")
			conn.row_factory = sql.Row
			cur = conn.cursor()
			cur.execute("SELECT * FROM stud_record")
			rows = cur.fetchall()
			return render_template("result_list.html", rows = rows, message = message)
		conn.close()


#For List

@app.route("/list")
def rec_list():
	conn = sql.connect("database.db")
	conn.row_factory = sql.Row
	cur = conn.cursor()
	cur.execute("SELECT * FROM stud_record")
	rows = cur.fetchall()

	conn.close()
	return render_template("record_list.html", rows = rows)

@app.route("/CourseTable")
def course_list():
	conn = sql.connect("database.db")

	conn.row_factory = sql.Row
	cur = conn.cursor()
	cur.execute("SELECT * FROM result")
	rows = cur.fetchall()

	conn.close()

	return render_template("Course_table.html", rows = rows)

#For Search

@app.route("/search", methods = ['POST', 'GET'])
def search():
	return render_template("search_er.html")

@app.route("/searching", methods = ['POST', 'GET'])
def searching():
	if request.method == "POST":
		try:
			find = request.form["srch"]
			print find
			conn = sql.connect("database.db")
			cur=conn.cursor()
			cur.execute("SELECT * FROM ALL_info where ID = ? or f_name=? or m_name=? or l_name=? or sex=? or yr_lvl=? or cour_id=? or cour_name=? or col_sch=? ", (find,find,find,find,find,find,find,find,find))

			coffee = cur.fetchall()
			print coffee
			msg = "existed"
		except:
			msg="not found"
		finally:
			return render_template("search_rec.html",msg=msg,coffee=coffee)


if __name__ == "__main__":
	app.run(debug = True)



